// 02_basic/03_string.js
let userName = "홍길동";

let oldStyle = "안녕하세요." + userName + "님\n반갑습니다.";
console.log(oldStyle);

// TODO: 백틱을 사용하여 위의 oldStyle과 같은 문자열을 만들어보세요.

// END
