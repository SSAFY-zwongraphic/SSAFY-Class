// 06_array.js
const curriculum = ["java", "frontend", "backend", "framework", "vue"];
