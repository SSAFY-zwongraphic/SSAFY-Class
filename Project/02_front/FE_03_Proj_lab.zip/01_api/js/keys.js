// TODO: 01. 개별적으로 발급받은 키를 등록하세요.
 const key_vworld = "v_world의 인증키";
 const key_kakao_javascript = "카카오자바스크립트키"
 const key_data = "data.go.kr key"; // data.go.kr 인증키(디코딩)

// END
