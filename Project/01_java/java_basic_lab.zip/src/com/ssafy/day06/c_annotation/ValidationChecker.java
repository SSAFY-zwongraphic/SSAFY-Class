package com.ssafy.day06.c_annotation;

import java.lang.reflect.Field;

public class ValidationChecker {
    public static StringBuilder validationCheck(Object obj) throws IllegalArgumentException, IllegalAccessException {
        StringBuilder output = new StringBuilder();
        // TODO: obj의 field 중 EMAIL, PASS, POSITIVE_NUM에 대한 validation을 처리해서 결과를 output에 담아서 반환하시오.

        // END
        return output;
    }
}
