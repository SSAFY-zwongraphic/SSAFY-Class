package com.ssafy.day03.a_inheritance.person;

public class SpiderManTest {

    public static void main(String[] args) {
        // TODO:  SpiderMan 객체를 만들고 기능을 사용해보자.

        // END
    }
}
