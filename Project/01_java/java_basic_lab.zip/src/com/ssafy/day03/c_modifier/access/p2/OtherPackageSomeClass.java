package com.ssafy.day03.c_modifier.access.p2;

import com.ssafy.day03.c_modifier.access.p1.Parent;

public class OtherPackageSomeClass {
    public void method() {
        // TODO: Parent 객체를 생성하고 이를 통해서 Parent의 멤버에 접근해보세요.

        // END
    }
}
