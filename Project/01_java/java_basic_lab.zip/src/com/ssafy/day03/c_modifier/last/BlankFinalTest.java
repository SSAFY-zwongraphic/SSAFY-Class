package com.ssafy.day03.c_modifier.last;

public class BlankFinalTest {
    private final String bloodType;

    // TODO: 위 코드가 정상적으로 컴파일되도록 처리하고 객체를 만들어보자.

    // END
}
