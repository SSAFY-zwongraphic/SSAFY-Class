package com.ssafy.day05.b_interface.relation;

// TODO: HandPhone를 충전 가능하게 설정하시오.
public class HandPhone extends Phone{}

// END
