package com.ssafy.day05.b_interface.replace;

public interface Calculator {
  int add(int a, int b);
}
