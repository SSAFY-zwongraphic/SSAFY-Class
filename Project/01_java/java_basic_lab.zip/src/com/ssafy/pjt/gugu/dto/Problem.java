package com.ssafy.pjt.gugu.dto;

public record Problem(int num1, int num2, int correctAnswer) {

}
