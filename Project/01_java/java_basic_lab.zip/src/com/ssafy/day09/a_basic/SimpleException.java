package com.ssafy.day09.a_basic;

public class SimpleException {
    public static void main(String[] args) {
        int[] intArray = { 10 };
        System.out.println(intArray[2]);
        System.out.println("프로그램 종료합니다.");
    }
}
