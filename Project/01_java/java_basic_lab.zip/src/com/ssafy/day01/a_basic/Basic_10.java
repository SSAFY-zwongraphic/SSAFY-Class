package com.ssafy.day01.a_basic;

import java.util.Random;

public class Basic_10 {
    public static void main(String[] args) {
        byFor();
        byWhile();
    }

    private static void byFor() {
        int sum = 0;
        int cnt = 100;
        double avg = 0;
        Random rand = new Random();
        // TODO: for 문장을 이용해서 cnt 만큼 주사위를 던지고 그 합과 평균(소수점 1자리)을 출력하시오.

        // END
    }

    private static void byWhile() {
        int sum = 0;
        int cnt = 100;
        double avg = 0;
        Random rand = new Random();
        // TODO: while 문장을 이용해서 cnt 만큼 주사위를 던지고 그 합과 평균(소수점 1자리)을 출력하시오.

        // END
    }

}
