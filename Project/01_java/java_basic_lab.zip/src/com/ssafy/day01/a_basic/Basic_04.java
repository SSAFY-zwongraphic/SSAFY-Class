package com.ssafy.day01.a_basic;

import java.math.BigDecimal;

public class Basic_04 {
    public static void main(String[] args) {
        float f1 = 2.0f;
        float f2 = 1.1f;
        float f3 = f1 - f2;
        System.out.println(f3);

        double d1 = 2.0;
        double d2 = 1.1;
        double d3 = d1 - d2;
        System.out.println(d3);

        // TODO: d1 - d2 를 정확히 계산해보자.

        // END
    }
}
