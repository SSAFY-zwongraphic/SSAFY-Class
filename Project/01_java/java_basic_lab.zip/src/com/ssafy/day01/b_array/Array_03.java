package com.ssafy.day01.b_array;

import java.util.Arrays;

public class Array_03 {
    public static void main(String[] args) {
        // TODO: "홍길동", "임꺽정", "장길산", "이몽룡"을 관리하는 배열을 만들고 내용을 출력하시오.
        //  임꺽정과 장길산의 위치를 변경해서 저장하고 출력하시오.

        // END
    }
}
