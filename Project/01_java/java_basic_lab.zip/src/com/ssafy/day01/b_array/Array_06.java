package com.ssafy.day01.b_array;

public class Array_06 {
    public static void main(String[] args) {
        char [] chars = "HelloJavaWorld.DreamisComeTrue".toCharArray();

        // TODO: 각 알파벳이 몇 번 사용 되었는지 사용 횟수를 출력 하세요.(사용된알파벳만 출력)
        //  문자열을 알파벳으로만 구성되었으며 모두 소문자로 간주한다.

        // END
    }
}
