package com.ssafy.day11.dto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

// TODO: 다음 클래스를 record 클래스로 작성해보세요.
//  Integer rank, String movieNm, String openDt, Integer audiAcc를 관리한다.
 public class BoxOffice{}

// END
